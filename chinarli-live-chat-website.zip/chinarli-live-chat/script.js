// CHINARLI live chat starter — Firebase Authentication + Cloud Firestore.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup,
  updateProfile, signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, collection, addDoc, query, orderBy, limit,
  onSnapshot, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const configured = firebaseConfig.apiKey && !firebaseConfig.apiKey.includes("PASTE_");
let auth=null, db=null, currentUser=null, unsubscribeMessages=null, activeGroup="general";
const groups=[
  ["💬","General Village","Everyday conversations and helpful updates.","general"],
  ["📢","Village News","Announcements and important information.","news"],
  ["📚","Education","Learning resources and student support.","education"],
  ["🌱","Agriculture","Farming ideas and local knowledge.","agriculture"],
  ["🤝","Youth & Activities","Activities, ideas and volunteering.","youth"],
  ["🎉","Events & Celebrations","Village events and gatherings.","events"]
];
const $=id=>document.getElementById(id);
const grid=$("groupGrid"), groupList=$("chatGroupList"), messages=$("messages");
$("year").textContent=new Date().getFullYear();

groups.forEach(([icon,title,desc,id])=>{
  const card=document.createElement("article"); card.className="group-card";
  card.innerHTML=`<div class="group-icon">${icon}</div><h3>${title}</h3><p>${desc}</p>`;
  card.addEventListener("click",()=>{selectGroup(id);$("chat").scrollIntoView({behavior:"smooth"});});
  grid.appendChild(card);
  const btn=document.createElement("button"); btn.className="chat-group"; btn.dataset.group=id;
  btn.innerHTML=`<span>${icon}</span><span><strong>${title}</strong><small>${desc}</small></span>`;
  btn.onclick=()=>selectGroup(id); groupList.appendChild(btn);
});

function toast(text){const t=$("toast");t.textContent=text;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),3500);}
function setAuthMessage(text){$("authMessage").textContent=text;}
function openModal(mode="signin"){setMode(mode);$("authModal").classList.add("show");$("authModal").setAttribute("aria-hidden","false");}
function closeModal(){$("authModal").classList.remove("show");$("authModal").setAttribute("aria-hidden","true");}
let mode="signin";
function setMode(next){mode=next;document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.mode===next));$("nameWrap").classList.toggle("hidden",next!=="signup");$("fullName").required=next==="signup";$("modalTitle").textContent=next==="signup"?"Create your account.":"Join your community.";$("submitAuth").textContent=next==="signup"?"Create account":"Sign in";setAuthMessage("");}
$("openLogin").onclick=()=>openModal("signin");$("joinBtn").onclick=()=>openModal("signup");$("noticeJoin").onclick=()=>openModal("signup");
$("closeModal").onclick=closeModal;$("authModal").addEventListener("click",e=>{if(e.target===$("authModal"))closeModal();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>setMode(t.dataset.mode));

function authError(e){const map={"auth/email-already-in-use":"This email already has an account.","auth/invalid-email":"Please enter a valid email address.","auth/weak-password":"Choose a stronger password (at least 8 characters).","auth/invalid-credential":"Email or password is incorrect.","auth/popup-blocked":"Allow pop-ups to use Google sign-in."};return map[e.code]||"Could not sign in. Please try again.";}
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!configured){setAuthMessage("Add your Firebase project settings to firebase-config.js first.");return;}
  const email=$("email").value.trim(), password=$("password").value;
  try{
    if(mode==="signup"){
      const name=$("fullName").value.trim(); if(!name){setAuthMessage("Enter your name.");return;}
      const cred=await createUserWithEmailAndPassword(auth,email,password); await updateProfile(cred.user,{displayName:name});
    }else await signInWithEmailAndPassword(auth,email,password);
    closeModal();toast("You are signed in.");
  }catch(err){setAuthMessage(authError(err));}
});
$("googleDemo").onclick=async()=>{
  if(!configured){setAuthMessage("Add Firebase settings and enable Google sign-in first.");return;}
  try{await signInWithPopup(auth,new GoogleAuthProvider());closeModal();}catch(e){setAuthMessage(authError(e));}
};

function selectGroup(id){
  activeGroup=id; const g=groups.find(x=>x[3]===id); $("activeGroupName").textContent=g[1];$("activeGroupDescription").textContent=g[2];
  document.querySelectorAll(".chat-group").forEach(b=>b.classList.toggle("active",b.dataset.group===id));
  listenMessages();
}
function listenMessages(){
  if(unsubscribeMessages){unsubscribeMessages();unsubscribeMessages=null;}
  if(!db||!currentUser){messages.innerHTML='<div class="chat-empty">Sign in to view messages in this group.</div>';return;}
  messages.innerHTML='<div class="chat-empty">Loading messages…</div>';
  const q=query(collection(db,"groups",activeGroup,"messages"),orderBy("createdAt","asc"),limit(100));
  unsubscribeMessages=onSnapshot(q,snap=>{
    messages.innerHTML="";
    if(snap.empty){messages.innerHTML='<div class="chat-empty">No messages yet. Start a friendly conversation!</div>';return;}
    snap.forEach(doc=>{
      const m=doc.data(), el=document.createElement("article");el.className="chat-message"+(m.uid===currentUser.uid?" mine":"");
      const who=document.createElement("b");who.textContent=m.name||"Village member";
      const body=document.createElement("p");body.textContent=m.text||"";
      const time=document.createElement("time");time.textContent=m.createdAt?.toDate?m.createdAt.toDate().toLocaleString():"Sending…";
      el.append(who,body,time);messages.appendChild(el);
    });
    messages.scrollTop=messages.scrollHeight;
  },err=>{messages.innerHTML='<div class="chat-empty">Unable to load chat. Check your Firestore rules and internet connection.</div>';console.error(err);});
}
$("messageForm").addEventListener("submit",async e=>{
  e.preventDefault();const input=$("messageInput"),text=input.value.trim();if(!text||!currentUser||!db)return;
  input.disabled=true;$("sendMessage").disabled=true;
  try{await addDoc(collection(db,"groups",activeGroup,"messages"),{text,uid:currentUser.uid,name:currentUser.displayName||currentUser.email,createdAt:serverTimestamp()});input.value="";}
  catch(err){toast("Message not sent. Check your connection and chat permissions.");console.error(err);}
  finally{input.disabled=false;$("sendMessage").disabled=false;input.focus();}
});

function updateAuthUI(user){
  currentUser=user;
  $("chatStatus").textContent=user?`Signed in as ${user.displayName||user.email}`:"Sign in to join the conversation";
  $("openLogin").textContent=user?"Sign out":"Sign in";
  $("messageInput").disabled=!user||!db;$("sendMessage").disabled=!user||!db;
  $("messageInput").placeholder=user?"Write a message to the group…":"Sign in to send a message…";
  if(user){$("openLogin").onclick=async()=>{await signOut(auth);toast("You have signed out.");};}
  else $("openLogin").onclick=()=>openModal("signin");
  listenMessages();
}

if(configured){
  try{
    const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
    onAuthStateChanged(auth,updateAuthUI);
  }catch(e){$("chatStatus").textContent="Firebase setup error — check firebase-config.js";console.error(e);}
}else{
  $("chatStatus").textContent="Setup required: connect Firebase to activate live chat";
  $("messages").innerHTML='<div class="chat-empty">The chat interface is ready. Add your Firebase project settings and deploy the security rules to activate real-time messaging.</div>';
  $("messageInput").placeholder="Firebase setup required before chatting"; 
}
selectGroup("general");
